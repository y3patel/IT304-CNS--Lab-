#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/sendfile.h>

#define PORT 8010
#define BUF 128

int main(int argc, char** argv){
    
    int l_sock, c_sock, fd, fsize, n, k;
    //int *sock;
    char buf[BUF],req[50],reply[50],err[20];;
    struct sockaddr_in ser,cli;
    struct stat obj;
    
    /*if (l_sock = socket(AF_INET,SOCK_STREAM,0) < 0){
        printf("Cannot create socket\n");
        exit(1);
    }*/
    
    l_sock = socket(AF_INET,SOCK_STREAM,0);
    
    bzero(&ser,sizeof(ser));
    ser.sin_family = AF_INET;
    ser.sin_addr.s_addr = htonl(INADDR_ANY);
    ser.sin_port = htons(PORT);
    
    if (bind(l_sock,(struct sockaddr *) &ser,sizeof(ser)) < 0){
        printf("Failed to bind the socket\n");
        exit(2);
    }
    
    listen(l_sock,5);
    
    //sock = &(l_sock);
    
    int c = sizeof(struct sockaddr_in);
    
    while(1){
    
        c_sock = accept(l_sock, (struct sockaddr*)&cli, (socklen_t*)&c);
        
        while(1){
            
            strcpy(req,"\0");
            
            recv(c_sock,req,50,0);
            
            //printf("%s\n",req);
            
            if(strcmp(req,"\0")==0){
                continue;
            }
            
            //printf("Hiiii\n");
            
            char *parsecmd;
            char *parsefile;
            parsecmd = strtok(req," ");
            parsefile = strtok(NULL," ");
            
            if (strcmp(parsecmd,"get")==0){
                //printf("get received.\n");
                if(access(parsefile,F_OK) < 0){
                    //printf("Hiii\n");
                    strcpy(reply,"NACK");
                    send(c_sock,reply,sizeof(reply),0);
                }
                else{
                    //printf("Hiii\n");
                    strcpy(reply,"PACK");
                    send(c_sock,reply,sizeof(reply),0);
                    
                    struct stat obj;
                    
                    stat(parsefile,&obj);
                    fd = open(parsefile,O_RDONLY,S_IRUSR);
                    //printf("%d\n",fd);
                    fsize = obj.st_size;
                    send(c_sock,&fsize,sizeof(fsize),0);
                    
                    //printf("%d",fsize);
                    
                    //int tosend = fsize,sent;
                    //off_t offset=0;
                    
                    /*while(tosend>0){
                        sent = sendfile(c_sock,fd,&offset,tosend);
                        printf("%d",sent);
                        tosend -= sent;
                        offset += sent;
                    }*/
                    
                    while ( (n = read(fd, buf, BUF-1)) > 0){
		                buf[n] = '\0';
		                //printf("%s\n",buf);
		                write(c_sock,buf,n);
	                }
	                printf("file transfer completed \n");
                    
                    close(fd);
                }
            }
            else if (strcmp(parsecmd,"put")==0){
                recv(c_sock,&fsize,sizeof(fsize),0);
                
                printf("Size of file to be received:%d\n",fsize);
                
                fd = open("newserverfile.txt", O_TRUNC | O_CREAT | O_WRONLY, 0666);
                
                while ( (n = read(c_sock, buf, BUF-1)) > 0){
	                buf[n] = '\0';
	                //printf("%s\n",buf);	
	                write(fd,buf,n);
	                if( n < BUF-2)
		                break;
                }

                printf("file receiving completed \n");
                
                close(fd);
            }
            else if (strcmp(parsecmd,"ls")==0){
                
                system("ls > list.txt");
                
                stat("list.txt",&obj);
                fd = open("list.txt",O_RDONLY,S_IRUSR);
                
                //printf("%d\n",fd);
                
                fsize = obj.st_size;
                send(c_sock,&fsize,sizeof(fsize),0);
                
                while ( (n = read(fd, buf, BUF-1)) > 0){
	                buf[n] = '\0';
	                write(c_sock,buf,n);
                }
                
                close(fd);
            }
            else if (strcmp(parsecmd,"quit")==0){
                break;
            }
            else if (strcmp(parsecmd,"?")==0)continue;
            else {
                strcpy(err,"unknown error...\n");
                send(c_sock,err,sizeof(err),0);
            }
        }
    }
    //close(c_sock);
}

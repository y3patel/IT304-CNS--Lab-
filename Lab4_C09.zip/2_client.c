#include<sys/ioctl.h>
#include<arpa/inet.h>
#include<stdlib.h>
#include<net/if_arp.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netdb.h>
#include<string.h>
#include <stdio.h>
#include <sys/sendfile.h>

#define PORT 8010
#define BUF 128

int main(int argc, char** argv) {
    
    int sock_des,fd,fsize,n;
    char buf[BUF],cmd[50],cmd2[50],response[50];    
    struct sockaddr_in serv_addr;
    
    if (argc!=2){
        printf("%s takes exactly 1 argument, given as :\n%s server_address\n", "Connecting to ftp", argv[0]);
        exit(1);
    }
    
    /*if (sock_des = socket(AF_INET,SOCK_STREAM,0) < 0) {
        printf("Error creating tcp socket\n");
        exit(2);
    }*/
    
    sock_des = socket(AF_INET,SOCK_STREAM,0);
    
    bzero(&serv_addr,sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
    serv_addr.sin_addr.s_addr = inet_addr(argv[1]);
    //printf("Hii\n");
    
    //system("ls > a.txt");
    
    if (connect(sock_des,(struct sockaddr*) &serv_addr, sizeof(serv_addr)) < 0) {
        printf("Cannot connect to socket.\n");
        exit(3);
    }
    
    while(1){
    
        printf("[? for help]\n");
        printf("\n>");
        //scanf("%s",cmd);
        
        fgets(cmd,50,stdin);
        
        if ((strlen(cmd) > 0) && (cmd[strlen(cmd)-1] == '\n'))
            cmd[strlen(cmd)-1] = '\0';
        
        strcpy(cmd2,cmd);
        char *parsecmd;
        char *parsefile;
        parsecmd = strtok(cmd2," ");
        parsefile = strtok(NULL," ");
        //printf("%s\n",parsecmd);
        //printf("%s\n",parsefile);
        //printf("%s\n",parsecmd[1]);
        
        //printf("%s\n%s\n",cmd,cmd2);
        
        send(sock_des,cmd,sizeof(cmd),0);
        
        if (strcmp(parsecmd,"get")==0){
            recv(sock_des,response,sizeof(response),0);
            if(strcmp(response,"PACK")==0){
                recv(sock_des,&fsize,sizeof(fsize),0);
                
                printf("File size:%d\n",fsize);
                
                fd = open("newclientfile.txt",O_TRUNC | O_CREAT  | O_WRONLY, 0666);
                
                /*char *data;
                data = malloc(fsize);
                recv(sock_des,data,sizeof(data),0);
                write(fd,data,sizeof(data));
                */
                
                while ( (n = read(sock_des, buf, BUF-1)) > 0){
		            buf[n] = '\0';
		            //printf("%s\n",buf);	
		            write(fd,buf,n);
		            if( n < BUF-2)
			            break;
	            }
	
	            printf("file receiving completed \n");
                
                close(fd);
            }
            else{
                printf("File doesn't exist\n");
            }
        }
        else if (strcmp(parsecmd,"put")==0){
        
            struct stat obj;
                    
            stat(parsefile,&obj);
            
            fd = open(parsefile,O_RDONLY,S_IRUSR);
            fsize = obj.st_size;
            send(sock_des,&fsize,sizeof(fsize),0);
            
            while ( (n = read(fd, buf, BUF-1)) > 0){
	            buf[n] = '\0';
	            //printf("%s\n",buf);
	            write(sock_des,buf,n);
            }
            printf("file transfer completed \n");
            
            close(fd);
        }
        else if (strcmp(parsecmd,"ls")==0){
            recv(sock_des,&fsize,sizeof(fsize),0);
            
            //printf("%d\n",fsize);
            
            while ( (n = read(sock_des, buf, BUF-1)) > 0){
	            buf[n] = '\0';
	            printf("%s\n",buf);	
	            if( n < BUF-2)
		            break;
            }
        }
        else if (strcmp(parsecmd,"?")==0){
            printf("get \"filename\" - To get a file from remote host\n");
            printf("put \"filename\" - To put a file on remote host\n");
            printf("ls - To list files in directory of remote host\n");
            printf("quit\n");
        }
        else if (strcmp(parsecmd,"quit")==0){
            exit(0);
        }
        else {
            printf("Unknown command\n ----> Use either \"get\" or \"put\"\n");
        }
    }
}
